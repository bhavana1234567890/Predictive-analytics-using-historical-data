# Predictive Analytics Using Historical Data

## Project Overview
This project analyzes historical monthly sales data and builds a predictive model to forecast future sales trends.

## Objectives
- Clean and preprocess historical data
- Analyze historical sales trends
- Build a regression-based predictive model
- Evaluate model accuracy
- Compare actual and predicted sales
- Forecast the next 12 months
- Visualize historical trends and future predictions

## Key Features
1. Historical data preprocessing
2. Feature engineering using time and seasonal features
3. Linear Regression predictive model
4. Model evaluation using MAE, RMSE and R²
5. Actual vs Predicted visualization
6. 12-month future forecasting

## Technologies Used
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn

## Dataset
`historical_sales.csv` contains monthly sales values from January 2022 to December 2025.

## How to Run

Install required libraries:

```bash
pip install pandas numpy matplotlib scikit-learn
```

Run:

```bash
python predictive_analytics.py
```

## Generated Outputs
The script creates:
- `outputs/model_metrics.csv`
- `outputs/actual_vs_predicted.csv`
- `outputs/future_forecast.csv`
- `outputs/historical_trend.png`
- `outputs/actual_vs_predicted.png`
- `outputs/future_forecast.png`

## Model Evaluation
- **MAE:** Average absolute prediction error.
- **RMSE:** Penalizes larger prediction errors more strongly.
- **R² Score:** Indicates how much variation in the target is explained by the model.

## Expected Outcome
Successfully develop a predictive analytics solution that cleans and preprocesses historical data, identifies trends and patterns, builds a regression-based forecasting model, evaluates prediction accuracy, and visualizes actual versus predicted results and future sales forecasts.

## Conclusion
The project demonstrates practical skills in data preprocessing, feature engineering, predictive modeling, model evaluation, trend analysis, visualization, and data-driven forecasting.
