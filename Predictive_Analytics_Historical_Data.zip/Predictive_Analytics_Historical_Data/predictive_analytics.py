"""
Predictive Analytics Using Historical Data
------------------------------------------
Project: Monthly Sales Forecasting
Model: Linear Regression with time and seasonal features
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 1. Load historical data
df = pd.read_csv(os.path.join(BASE_DIR, "historical_sales.csv"))
df["Date"] = pd.to_datetime(df["Date"])

# 2. Clean and preprocess
df = df.drop_duplicates().sort_values("Date").reset_index(drop=True)
df["Sales"] = pd.to_numeric(df["Sales"], errors="coerce")
df["Sales"] = df["Sales"].interpolate().ffill().bfill()

# 3. Feature engineering
df["Time_Index"] = np.arange(len(df))
df["Month"] = df["Date"].dt.month
df["Year"] = df["Date"].dt.year
df["Month_Sin"] = np.sin(2 * np.pi * df["Month"] / 12)
df["Month_Cos"] = np.cos(2 * np.pi * df["Month"] / 12)

features = ["Time_Index", "Month_Sin", "Month_Cos"]
X = df[features]
y = df["Sales"]

# 4. Train/test split (chronological to respect time order)
split = int(len(df) * 0.80)
X_train, X_test = X.iloc[:split], X.iloc[split:]
y_train, y_test = y.iloc[:split], y.iloc[split:]

# 5. Train regression model
model = LinearRegression()
model.fit(X_train, y_train)

# 6. Evaluate
predictions = model.predict(X_test)
mae = mean_absolute_error(y_test, predictions)
rmse = np.sqrt(mean_squared_error(y_test, predictions))
r2 = r2_score(y_test, predictions)

metrics = pd.DataFrame({
    "Metric": ["MAE", "RMSE", "R2 Score"],
    "Value": [mae, rmse, r2]
})
metrics.to_csv(os.path.join(OUTPUT_DIR, "model_metrics.csv"), index=False)

print("\nMODEL EVALUATION")
print(metrics.to_string(index=False))

# 7. Actual vs predicted visualization
test_results = df.iloc[split:][["Date", "Sales"]].copy()
test_results["Predicted_Sales"] = predictions
test_results.to_csv(os.path.join(OUTPUT_DIR, "actual_vs_predicted.csv"), index=False)

plt.figure(figsize=(11, 5))
plt.plot(test_results["Date"], test_results["Sales"], label="Actual Sales")
plt.plot(test_results["Date"], test_results["Predicted_Sales"], label="Predicted Sales")
plt.title("Actual vs Predicted Sales")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "actual_vs_predicted.png"), dpi=150)
plt.close()

# 8. Historical trend visualization
plt.figure(figsize=(11, 5))
plt.plot(df["Date"], df["Sales"], label="Historical Sales")
plt.title("Historical Monthly Sales Trend")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "historical_trend.png"), dpi=150)
plt.close()

# 9. Forecast next 12 months
last_date = df["Date"].max()
future_dates = pd.date_range(last_date + pd.offsets.MonthBegin(1), periods=12, freq="MS")
future = pd.DataFrame({"Date": future_dates})
future["Time_Index"] = np.arange(len(df), len(df) + len(future))
future["Month"] = future["Date"].dt.month
future["Month_Sin"] = np.sin(2 * np.pi * future["Month"] / 12)
future["Month_Cos"] = np.cos(2 * np.pi * future["Month"] / 12)

future["Predicted_Sales"] = model.predict(future[features])
future["Predicted_Sales"] = future["Predicted_Sales"].round(2)
future.to_csv(os.path.join(OUTPUT_DIR, "future_forecast.csv"), index=False)

# 10. Forecast visualization
plt.figure(figsize=(12, 5))
plt.plot(df["Date"], df["Sales"], label="Historical Sales")
plt.plot(future["Date"], future["Predicted_Sales"], marker="o", label="12-Month Forecast")
plt.title("Future Sales Forecast")
plt.xlabel("Date")
plt.ylabel("Sales")
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "future_forecast.png"), dpi=150)
plt.close()

print("\n12-MONTH FORECAST")
print(future[["Date", "Predicted_Sales"]].to_string(index=False))
print("\nProject completed. Check the outputs folder for results and charts.")
